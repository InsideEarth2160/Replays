Die map muss in das Verzeichnis c:\...\Eigene Dateien\Earth 2160 files\Levels\ entpackt werden.

Have fun!

Erstellt von Major